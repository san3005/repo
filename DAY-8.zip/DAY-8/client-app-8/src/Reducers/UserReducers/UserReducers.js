export const UserDataReducer=(state={},action)=>{
    switch(action.type){
        case'USER_LOGIN':
        return{userdetails:action.payload}
        case 'USER_LOGOUT':
            return{}
            case 'USER_LOGIN_FAIL':
                return{error:action.payload}
                default:
                    return state
    }

}

//not necessary
export const UserDetailsReducer=(state={user:{}},action)=>{
    switch(action.type){
        case'USER_DETAILS_SUCCESS':
        return{user:action.payload}
        case 'USER_LOGOUT':
            return{}
            case 'USER_DETAILS_FAIL':
                return{error:action.payload}
                default:
                    return state
    }

}