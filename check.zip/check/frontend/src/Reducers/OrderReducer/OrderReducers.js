export const OrderDataReducer=(state={},action)=>{
switch(action.type){
    case'ORDER_SUCCESS':
    return{
        order:action.payload,
        success:true
    }
    case'ORDER_FAILED':
    return{
        error:action.payload
    }
    default:
        return state;
}
}

export const OrderDetailsDataReducer=(state={OrderedList:[],Shippingaddress:{}},action)=>{
    switch(action.type){
        case'ORDER_DETAILS_SUCCESS':
        return{
            order:action.payload,
            success:true
        }
        case'ORDER_DETAILS__FAILED':
        return{
            error:action.payload
        }
        default:
            return state;
    }
    }
    
export const OrderUserDataReducer=(state={fav:[]},action)=>{
    switch(action.type){
        case'MY_ORDER_SUCCESS':
        return{
fav:action.payload,
            success:true
        }
        case'MY-ORDER_FAILED':
        return{
            error:action.payload
        }
        case'MY_ORDER_RESET':
        return{
            orders:[]

        }
        default:
            return state;
    }
    }

