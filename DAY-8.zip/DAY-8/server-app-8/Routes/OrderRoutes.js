import express from 'express';
const router=express.Router();
 import {creatingOrder} from '../controllers/OrderControllers.js'
import {protectede} from '../middleware/Authentication.js'

// router.get("/",getuser)
router.post("/",protectede,creatingOrder)

// /users/loginuser
export default router;