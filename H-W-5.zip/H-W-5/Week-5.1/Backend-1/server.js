const express= require('express');
const mongoose= require('mongoose');
const cors=require('cors');

const app=express();



app.use(express.json());
app.use(cors());

mongoose.connect("mongodb://127.0.0.1:27017/handson",{
    useNewUrlParser:true,    
useUnifiedTopology:true
})

.then(()=>console.log("connected to database"))
.catch(console.err);


const Handson=require('./models/Pagination.js');

app.get('/details', async(req,res)=>{
    const PAGE_SIZE = 5;
  const page = parseInt(req.query.page || "0");
  const total = await Handson.countDocuments({});
  const results = await Handson.find({})
    .limit(PAGE_SIZE)
    .skip(PAGE_SIZE * page);
    res.json({
        totalPages: Math.ceil(total / PAGE_SIZE),
        results,
    });
})
app.listen(8000);

