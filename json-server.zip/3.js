const postsList=document.querySelector('.post-list');
const addPostForm=document.querySelector('.add-post-form');
const titlevalue=document.getElementById('title-value');
const bodyvalue=document.getElementById('body-value');
const btnSubmit=document.querySelector('.btn');
let output='';
const url='http://localhost:3000/posts';
const renderPost=(posts)=>{
    posts.forEach(post =>
        {
output+=`
   <div class="card mt-4 col-md-6 bg-light" >
   <div class="card-body" data-id=${post.id}>
  <h5 class="card-title">${post.title}</h5>
  <h6 class="card-subtitle mb-2 text-muted"></h6>
  <p class="card-text">${post.body}.</p>
  <a href="#" class="card-link" id="edit-post">Edit</a>
  <a href="#" class="card-link " id="delete-post">Delete</a>
  </div>
  </div>
`;        });
postsList.innerHTML=output;
}



//get-read posts
//method:get
fetch(url)
.then(res=>res.json())
.then(data=>renderPost(data))
postsList.addEventListener('click',(e)=>
{
    e.preventDefault();
let delButtonispressed=e.target.id=='delete-post';
let editButtonispressed=e.target.id=='edit-post';
let id=(e.target.parentElement.dataset.id);

//delete method 
if(delButtonispressed){
fetch("http://localhost:3000/posts/"+id,{
method:'DELETE',
})
.then(res=>res.json())
.then(()=>location.reload())
}if(editButtonispressed){
const parent=e.target.parentElement;
let titlecontent=parent.querySelector('.card-title').textContent;
let bodycontent=parent.querySelector('.card-text').textContent;


titlevalue.value=titlecontent;
bodyvalue.value=bodycontent;



}
//update
//method:PATCH
btnSubmit.addEventListener('click',(e)=>{
    e.preventDefault();
    fetch("http://localhost:3000/posts/"+id,{
        method:'PATCH',
  
    headers:{
        'Content-Type':'application/json'
    },
body:JSON.stringify({
    title:titlevalue.value,
    body:bodyvalue.value
})  })
    .then(res=>res.json())
    .then(()=>location.reload())
})

}

);

//create -insert new post
//method:post

addPostForm.addEventListener('submit',(e)=>{
    e.preventDefault();
    console.log("form submitted");
    console.log(titlevalue.value);
    
    
    fetch(url,{
        method:'POST',
        headers:{
            'Content-Type':'application/json'
        },
        body:JSON.stringify({
            title:titlevalue.value,
            body:bodyvalue.value
        })
    })
    .then(res=>res.json())
    .then(data=>{
        const dataarr=[];
        dataarr.push(data);
        renderPost(dataarr);
    })
    //
    //reset input field
    titlevalue.value='';
    bodyvalue.value='';
})