import Product from '../models/Productmodel.js';
const getProducts=async(req,res)=>{
    const data=await Product.find();

      res.json(data);
}
const getProduct=async(req,res)=>{
    const data= await Product.findById(req.params.id);
    res.json(data);
}
// const updateproduct=async (req,res)=>{
//     const data=await Product.findById(req.params.id);
//     data.CountInStock=
// }
// const Updateprofileofusers =async(req,res)=>{
//     const user=await User.findById(req.user._id)
//     if(user){
//        user.Name= req.body.Name|| user.Name
//     user.Email=req.body.Email || user.Email
// if(req.body.Password){
//     user.Password=req.body.Password
// }
// //update user
// const updateduser=await user.save()
// res.json({
//     _id:updateduser._id,
//     Name:updateduser.Name,
//     Email:updateduser.Email,
//     IsAdmin:updateduser.IsAdmin,
//     token:generatenewtoken(updateduser._id),
// })
//     }
//     else{
//         res.json("user not found").status(400)
//     }
//     }
    

export{getProducts,getProduct}