import mongoose from 'mongoose';
const Schema=mongoose.Schema;
const OrderSchema = new Schema({
    user:{
type:mongoose.Schema.Types.ObjectId,
required:true,
ref:'User'
    },

OrderedList:[
    {

        Name:{
            type:String,
        },
        Img:{
            type:String,

        },
        CountInstock:{
            type:Number
        },
        qty:{
            type:Number,

        },
        Price:{
            type:Number,
        },
        product:{
            type:mongoose.Schema.Types.ObjectId,
            ref:'Product',
        }
    }
],
Shippingaddress:{
    name:{type:String},
    address:{type:String},
    states:{type:String},
    zipcode:{type:String},
    City:{type:String},


},
payment:{
    type:'String',
},
paymentoutcome:{
 id:{type:String},
 status:{type:String},
 recenttime:{type:String},
 email:{type:String},



},
tax:{
    type:'Number',
    
},
shippingprice:{
    type:'Number',
    
},
totalprice:{
    type:'Number',
    
},
IsPaid:{
    type:'Boolean',
    default:false,
},
paiddate:{
    type:Date,
},
IsDelivered:{
    type:'Boolean',
    default:false,

},
delivereddate:{
    type:Date,
}

},

{
    timestamps:true
}

)




const Order=mongoose.model("Order",OrderSchema);
export default Order;