import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';

const Searchbox = () => {
    const[words,setWords]=useState("");
   const navigate= useNavigate();


    const searchhandler=(e)=>{
        e.preventDefault();
       
        if(words.trim()){
navigate (`/home/${words}`)
        }
        else{
            navigate("/home")
        }
    }
  return (
    <div>
        <form onSubmit={searchhandler} >
        <input type="text" value={words} name="query" onChange={(e)=>setWords(e.target.value)} placeholder="search"/>

        <button type="submit" className='btn btn-dark' >Search</button>
        </form>
    </div>
  )
}

export default Searchbox