import express from 'express';
const router=express.Router();
 import {Authenticatingusers,   RegisteringUsers,Profileofusers, Updateprofileofusers} from '../controllers/UserControllers.js'
import {protectede} from '../middleware/Authentication.js'

// router.get("/",getuser)
router.post("/loginuser",Authenticatingusers)
router.get("/userprofile",protectede,Profileofusers).put("/update",protectede,Updateprofileofusers)
router.post("/Registration",RegisteringUsers)
// /users/loginuser
export default router;