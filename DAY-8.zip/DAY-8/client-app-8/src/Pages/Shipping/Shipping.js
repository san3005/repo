import React,{useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Navigate, NavLink, useNavigate } from 'react-router-dom';
import { shippingaddress } from '../../Actions/CartAction/CartAction';
import Checkout from './Checkout';

const Shipping = () => {
    const dispatch=useDispatch();
    const cart=useSelector((state)=>state.cartdata);

    const{shippingdetails}=cart;
    const userdata=useSelector(state=>state.userdata);
    const{userdetails}=userdata;
    console.log(cart)
    const navigate=useNavigate()
    const handleshipping=(e)=>{
        e.preventDefault();
    }
    const[name,setName]=useState(shippingdetails.name)
    const [address,setAddress]=useState(shippingdetails.address);
    const [city,setCity]=useState(shippingdetails.city);
    const [states,setStates]=useState(shippingdetails.states);
    const [zipcode,setZipcode]=useState(shippingdetails.zipcode)

const continuehandler=()=>{
    dispatch(shippingaddress({name,address,city,states,zipcode}))
    console.log('hi im contineu')

navigate('/payment');

}


   
  
  return (
    <div className="container">
        <Checkout step1 step2/> 
        <h1>Shipping</h1>
        <form         onSubmit={(e)=>handleshipping(e)}>
        <div class="login__field">
                <i class="login__icon bx bx-home"></i>
					<input type="text" class="login__input" value={name} onChange={(e)=>setName(e.target.value)} required/>
                    
            	</div>
		<div class="login__field">
                <i class="login__icon bx bx-home"></i>
					<input type="text" class="login__input"placeholder="  Address" value={address} onChange={(e)=>setAddress(e.target.value)} required/>
                    
            	</div>
                <div class="login__field">
                <i class="login__icon bx bxs-city"></i>
					<input type="text" class="login__input"placeholder="  city" value={city} onChange={(e)=>setCity(e.target.value)} required/>
                    
            	</div>
                <div class="login__field">
                <i class="login__icon bx bx-location-plus"></i>
					<input type="text" class="login__input"placeholder="  State" value={states} onChange={(e)=>setStates(e.target.value)} required/>
                    
            	</div>
                <div class="login__field">
                <i class="login__icon bx bx-code-alt"></i>
					<input type="text" class="login__input"placeholder="  Zipcode" value={zipcode} onChange={(e)=>setZipcode(e.target.value)} required/>
                    
            	</div>
              
                <div class="login__field">
<button type="submit" onClick={continuehandler}>Continue</button>                    
            	</div>

        </form>

        
    </div>
    
  )
}

export default Shipping