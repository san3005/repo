import React,{useState,useEffect} from 'react'
import axios from "axios";
import Card from './Card';
import './index.css'

const ProductCard = () => {
    const[data,setData]=useState([])
    useEffect(() => {
        axios.get("http://localhost:8000/products")
        .then(res=>setData(res.data))    
    
    }, [])
    
    
  return (
       <div className="row">      
       <marquee className="mt-3 bg-dark " style={{color:"white"}}>  Get upto 25%off on nike jordan by ordering today.Offer expires tomorrow </marquee>  
         {data.map (product=>(
             <div key={product._id}className='col-sm-12 col-lg-4 col-xl-3 col-md-6'>
                 <Card product={product}/>
                 </div>

        ))} 
        
   
        </div>
  )
}

export default ProductCard