import mongoose from 'mongoose';
const Schema=mongoose.Schema;
import dummy from 'mongoose-dummy';

const CartSchema=new Schema({
product:{
   type:mongoose.Schema.Types.ObjectId,
   ref:'Product'

},
Name:{
    type:String,
    required:true
},
Img:{
    type:Number,
    required:true
},
Price:{
    type:Number,
    required:true
},
CountInstock:{
    type:Number,
    required:true
},
qty:{
    type:Number,
    required:true
}


},
{
    timestamps:true
}
)
const Cart=mongoose.model("Cart",CartSchema);
// let randomObject = dummy(Cart, {
//         returnDate: true
//     })
//     console.log(randomObject);
    
export default (Cart);
