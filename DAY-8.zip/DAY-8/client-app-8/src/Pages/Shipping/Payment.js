import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { paymentmethod } from '../../Actions/CartAction/CartAction';
import Checkout from './Checkout'

const Payment = () => {
    const dispatch=useDispatch();
    const userdata=useSelector(state=>state.userdata);
    const{userdetails}=userdata;


    
    const [paymenttype,setPaymenttype]=useState("paypal")
    const cart=useSelector((state)=>state.cartdata);
const navigate=useNavigate()
    const{shippingdetails}=cart;
    if(!shippingdetails){
        console.log(shippingdetails);
        navigate('/shipping')
    }
    const handleshipping=(e)=>{
        e.preventDefault();
        dispatch(paymentmethod({paymenttype}))
        navigate('/placeorder');
  }
  
 
  

   console.log(paymenttype)
  
  return (
    <div className="container">
                <Checkout step1 step2 step3/> 

        <h1>payment</h1>
        <form         onSubmit={(e)=>handleshipping(e)}>
        <div class="login__field">
        <i class="login__icon bx bxl-paypal"></i>

                <label htmlFor='paypal'><input type="radio" class="login__input" value="paypal" id="paypal"  name="paymenttype"  onChange={(e)=>setPaymenttype(e.target.value)} checked/>Paypal</label>
                    
            	</div>
		
                <div class="login__field">

        <label htmlFor='stripe'>                   
     <input type="radio" class="login__input mx-3" value="stripe" id="stripe"  name="paymenttype"  onChange={(e)=>setPaymenttype(e.target.value)}/>Stripe<i class="login__icon bx bxl-mastercard"></i></label>
                    
            	</div>

                <div class="login__field">
<button>Continue</button>                    
            	</div>

        </form>

        
    </div>
    
  )

}

export default Payment