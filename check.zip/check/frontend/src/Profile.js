


import React,{useEffect, useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { myfav } from './Actions/OrderActions/OrderActions';

const Profile = () => {
  const dispatch=useDispatch();
      const navigate=useNavigate()
      useEffect(() => {
        dispatch( myfav())

      
       
      }, [])
      // useEffect(() => {
      //   window.location.reload()
      
    
      // }, [10])
      // useEffect(() => {

      //   const conditione=  ()=>{
      
      //   }
      //    const timer=setTimeout(()=>{
      //      conditione()
      //    },1000);
      //    return ()=>{clearTimeout(timer);
      //   };
      //   }, []);
        
        // window.location.reload()
    
      
      // const userdetailsdata=useSelector(state=>state.userdetails);
      // const{userdetails,error}=userdetailsdata;
      const orderuserdata=useSelector(state=>state.orderuserdata);
      const{fav,error}=orderuserdata
      console.log(fav,"profile") ;


      
//     const handlesingleorder=(id)=>{
// navigate(`/orders/${id}`)    }  
      
//   return (
//     <>
//     <div className="container">
//       <h2>My orders</h2>
      
//     {error ? (
//       <div className="alert alert-danger" role="alert">
// {error}    </div>
//     )
//   :(

//     <div className='container'>
//       <div className="table-responsive">

// <table className="table table-hover">
//   <thead>
//   <tr>
//     <th>Index</th>
// <th> ID</th>
// <th> Date</th>
// <th> Paid by</th>
// <th> Total Amount</th>
// <th> User Id</th>
// {/* <th>Products bought</th>
// <th>Quantity bought</th> */}
// </tr>
// </thead>
// <tbody>
// {orders.data==null 
//  ? "Loading..."
//  : (orders.data.map((singleorderdetails,i)=>(
//   console.log(singleorderdetails.IsPaid,"ispaid"),
//   <tr key={i}>
//     <td>{i+1}</td>
// <td>{singleorderdetails._id}</td>
// <td>{singleorderdetails.createdAt}</td>
// <td>{singleorderdetails.payment}</td>
// <td>₹{singleorderdetails.totalprice}</td>
// <td>{singleorderdetails.user}</td>
// {/* <td>{singleorderdetails.OrderedList.map((single,i)=>(
//  <div key={i}> {single.Name} 
// </div>))}</td>
// <td>{singleorderdetails.OrderedList.map((single,i)=>(
//  <div key={i}> {single.qty}
// </div>))}</td> */}
// {/* <td>{singleorderdetails.OrderedList.map((single,i)=>(
//  <div key={i}> <img src={single.Img} style={{width:"100px",height:"100px"}}/>,
// </div>))}</td> */}
// {/* <td><button onClick={()=>handlesingleorder(singleorderdetails._id)}>View</button></td> */}

//   </tr>
// )))
// }
// </tbody>
// </table>
// </div>
// </div>

//   )
  
//   }
//        </div>
//  </>

//   )
return(
    <>
          <div className="table-responsive">

<table className="table table-hover">
  <thead>
  <tr>
    <th>Index</th>
<th> ID</th>
<th> Date</th>
<th> Paid by</th>
<th> Total Amount</th>
<th> User Id</th>
{/* <th>Products bought</th>
<th>Quantity bought</th> */}
</tr>
</thead>
<tbody>

    {
        fav.data==null 
            ? "Loading..."
            : (fav.data.map((singlefav,i)=>(

           <>
           {console.log(singlefav)}
<tr>
    <td>{singlefav.Favbook.Name}</td>
    <td>{singlefav.Favbook.Author}</td>
    <td>{singlefav.Favbook.Category}</td>
    <td>{singlefav.Favbook.Language}</td>
    <td>{singlefav.Favbook.Description}</td>
    <td>{singlefav.user}</td>

</tr>
           </>
            )))}
            </tbody>
</table>
</div>
</>
)
            }

export default Profile