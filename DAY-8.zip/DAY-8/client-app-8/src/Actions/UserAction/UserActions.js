import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const userlogin=(email,password)=>async(dispatch)=>{
    try{

        const config={
headers:{
"Content-Type":"application/json"
}
        }
        const {data}= await axios.post("http://localhost:8001/users/loginuser",{"Email":email,"Password":password},config)
console.log(data);
        dispatch({
           type:'USER_LOGIN',
           payload:data

        })
        localStorage.setItem("userdetails",JSON.stringify(data));
toast.success("logged in")
    }
    catch(error){
    dispatch({type:'USER_LOGIN_FAIL',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})
        toast.warning('Login failed')

    }
}
export const userlogout=()=>async(dispatch)=>{
    localStorage.removeItem("userdetails");
    localStorage.removeItem("shippingdetails")

dispatch({
    type:'USER_LOGOUT'
})


}


export const Getdetails=(id)=>async(dispatch,getState)=>{
    try{
        const {userlogin:{userdetails}}=getState()

        const config={
headers:{
"Content-Type":"application/json",
Authorization:`Bearer ${userdetails.token}`
}
        }
        const {data}= await axios.post(`http://localhost:8001/users/loginuser/${id}`,config)
console.log(data);
        dispatch({
           type:'USER_DETAILS_SUCCESS',
           payload:data

        })
       
        

    }
    catch(error){
dispatch({type:'USER_DETAILS_FAIL',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}
