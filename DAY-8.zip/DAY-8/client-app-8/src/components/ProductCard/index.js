import React,{useEffect,useState} from 'react'
import { useDispatch,useSelector } from 'react-redux';
import axios from "axios";
import Card from './Card';
import {productsdata} from '../../Actions/ProductActions/ProductActions'
import './index.css'



const ProductCard = () => {
  const[search,setSearch]=useState("")
console.log(search)

  const dispatch=useDispatch();
  const Productdata=useSelector(state=> state.Productdata)
  const {loading,error,products} =Productdata
 
    useEffect(() => {
      dispatch(productsdata());
        // axios.get("http://localhost:8080/products")
        // .then(res=>setData(res.data))    
    
    }, [])
    console.log(error)
  return (
    <>
    {error ? (<div class="alert alert-warning" role="alert">
    {error}
</div>):
    (
      <div>
      <marquee className="mt-4 bg-dark " style={{color:"white"}}>  Get upto 25%off on nike jordan by ordering today.Offer expires tomorrow </marquee>  
      <div className="row  gx-5 mx-4 my-3">
      <div className="col-6 col-sm-12 col-md-6">
      <img src= { require("./images/undraw_shopping_app_flsj.png")} alt="" className="img-fluid"  />
      </div>
      <div className="col-6 col-sm-12 col-md-6 mt-4">
      <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ut recusandae aliquid doloribus asperiores, veritatis corrupti unde, quidem voluptates modi odit quas ad excepturi explicabo iusto numquam dolor obcaecati molestias id totam cumque est temporibus. Aliquid sunt asperiores consequuntur tenetur quidem dolore excepturi neque ut optio et accusantium, assumenda maiores blanditiis laudantium praesentium saepe repellendus ab. Aperiam non quia a enim quidem nisi quos vero rerum eius, ipsa, molestias reprehenderit laborum veniam facilis repudiandae! Assumenda dolor nam libero corrupti dicta officia voluptate dolorum nemo blanditiis ullam rem illo sapiente nulla autem labore modi, nesciunt voluptatibus atque! Fugit quidem atque minima fuga, repellendus, molestiae quod totam iure reprehenderit laborum voluptatum laudantium quibusdam, in aliquid ipsam illo distinctio facere qui mollitia cum. Quam unde, ullam iusto, dolorem, ipsa nostrum voluptatum tempora aspernatur alias odit consectetur sunt reiciendis! Accusamus vel sed, nulla sapiente officia et. Expedita sit dolorem ex asperiores earum natus vitae deserunt.</p>  </div>
        </div>
      <div className="container">
      <h1>Latest Products</h1>
      
             <div className="row">     
             {/* <input type="text"  /> */}
               {products.map (product=>(
                   <div key={product.id}className='col-sm-12 col-lg-4 col-xl-3 col-md-6'>
                       <Card product={product}/>
                       </div>
      
              ))} 
              
              </div>
              </div>
              </div>
    )}
 
        </>

  )
}

export default ProductCard