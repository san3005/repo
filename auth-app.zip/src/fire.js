import firebase from 'firebase';

var firebaseConfig = {
    apiKey: "AIzaSyD7sHvRAOnNTWJ8jcyj2rCvpzvjha74afY",
    authDomain: "fir-aut-224d7.firebaseapp.com",
    projectId: "fir-aut-224d7",
    storageBucket: "fir-aut-224d7.appspot.com",
    messagingSenderId: "695429867907",
    appId: "1:695429867907:web:b575ce7052628d08c0aeb6",
    measurementId: "G-RZRX7ZCDP1"
  };

   const fire = firebase.initializeApp(firebaseConfig);

   export default fire;