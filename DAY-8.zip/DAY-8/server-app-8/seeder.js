import mongoose from 'mongoose';
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import products from './data.js';
import users from './users.js';
import User from './models/Usermodel.js'
import Review from './models/Reviewmodel.js'
import Order from './models/Ordermodel.js'
import Product from './models/Productmodel.js'

dotenv.config
mongoose.connect("mongodb+srv://SAN3005:SAN3005@cluster0.9coqr.mongodb.net/ECON12?authSource=admin&replicaSet=atlas-mfdnmj-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true",{ 
    useNewUrlParser:true,
    useUnifiedTopology:true
})
.then(()=>console.log('im connected to atlas  database bro' .underline.blue))
.catch(err=>console.log(`${err}`.underline.red ));


const importd=async()=>{
    try {
       await Order.deleteMany()
       await Product.deleteMany()
       await Review.deleteMany()
       await User.deleteMany()

       const createdusers= await User.insertMany(users)
       const adminuser=createdusers[0]._id
       const sampleproducts=products.map(product =>{
           return{...product,user:adminuser}
       })
       await Product.insertMany(sampleproducts)
       console.log("data imported".green)
    } catch (error) {
        console.error(`${error.message}`.red)
        
    }
}
const delted=async()=>{
try {
        await Order.deleteMany()
        await Product.deleteMany()
        await Review.deleteMany()
        await User.deleteMany()
    
} catch (error) {
    console.error(`${error.message}`.red)

}

}
if(process.argv[2]=='-d'){
    delted()
}
else{
    importd()
}