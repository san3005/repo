import React,{useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import {Link, NavLink, useNavigate} from 'react-router-dom'
import { userlogout } from '../../Actions/UserAction/UserActions';

import './index.css'
import Searchbox from './Searchbox';
const Header = () => {
  const dispatch=useDispatch()
  const userdata=useSelector(state=>state.userdata);
  const{userdetails}=userdata;
  const navigate=useNavigate()
// console.log(userdetails.IsAdmin,"header")
    const [show,setShow]=useState(false);
  const [value,setValue]=useState(0);
  const changeroute=()=>{
navigate("/")
  }
  const toggle=()=>{

    return setShow(!show);
  }
  const logout=()=>{
dispatch(userlogout());


navigate("/home");
  }
  return (
    <div className='container'>

      <div className="navbar">
        <div className="logo" style={{cursor:"pointer"}}>

         <NavLink to="/home" style={{fontSize:"22px"}}> Home</NavLink>

        {/* <div className="bag" style={{cursor:"pointer"}} onClick={changeroute}>
          <i className='bx bx-shopping-bag ' style={{color:"black",fontSize:"22px",marginRight:"50px"}}>
          </i>
         {console.log(userdata.userdetails)}
          </div>   */}

        </div>

        <div className={show ? "links active" : "links"}>
     
        {userdata.userdetails  ?(
          <>
                  <Link onClick={()=>toggle()} to="/recommendation">Recommendation List</Link>

 <Link onClick={()=>toggle()}to="/profile"> my fav<i className='bx bx-user ' ></i></Link>
 <Searchbox/>
<button  className="logout" onClick={logout} >Logout</button>


            </>
          
        ):(
 <Link onClick={()=>toggle()}to="/"> Signin <i className='bx bx-user ' ></i></Link>

          )}
              

        </div>
        <div className={show ?'bars-button active' : 'bars-button'} onClick={()=>toggle()}>
        <span></span>
        <span></span>
        <span></span>
        </div>
      </div>
 
    </div>
  )
}

export default Header