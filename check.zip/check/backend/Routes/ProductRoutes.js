import express from 'express';
const router=express.Router();
 import {getProduct,getProducts,bookreview} from '../Controllers/ProductControllers.js'
import { protectede } from '../Middleware/Authentication.js';



router.get("/",getProducts);
router.post("/review/:id",protectede,bookreview)
router.get("/:id",getProduct);

export default router;