
import logo from './logo.svg';
import './App.css';
import react, { useEffect, useState } from 'react';
import axios from "axios";

function App() {
  const[details,setDetails]=useState([]);
  const[pageNumber,setPageNumber]=useState(0);
  const [numberofpages,setNumberofpages]=useState(0);
  const pages = new Array(numberofpages).fill(null).map((v, i) => i);


 useEffect(()=>{
    axios.get(`http://localhost:8000/details?page=${pageNumber}`)
    // .then(({totalPages, results})=>{
    //   console.log(totalPages,results)
    //   setDetails(results);
    //   setNumberofpages(totalPages)
    // })
.then(res=>
  {
    setDetails(res.data.results);
    setNumberofpages(res.data.totalPages);
  })
  },[pageNumber]);
  
 

  return (

<div className="App">
  <h2 className="mb-3">Server Side Pagination</h2>
  <h3 className="mb-3">Page  {pageNumber+1} of 6</h3>
 
<table className="table table-striped table-hover align-items-center">
<thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">Name</th>
      <th scope="col">Age</th>
      <th scope="col">salary</th>
    </tr>
  </thead>
  <tbody>
    {
  details.map((employee,i)=>(


    <tr key={employee._id}>
<td>{employee.id}</td>
<td>{employee.employee_name}</td>
<td>{employee.employee_age}</td>
<td>{employee.employee_salary}</td>
    </tr>
  ))    
  }
  </tbody>
</table>
{pages.map((pageIndex)=>(
<button key={pageIndex} className='btn btn-outline-warning' onClick={()=>setPageNumber(pageIndex)}>{pageIndex + 1}</button>
))}
</div>
         )
}

export default App;