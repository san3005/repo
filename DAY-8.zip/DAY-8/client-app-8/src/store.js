import {createStore,combineReducers,applyMiddleware} from 'redux'
import thunk from 'redux-thunk';
import {composeWithDevTools} from '@redux-devtools/extension';
import {ProductDataReducer, singleproductreducer} from './Reducers/ProductReducer/Productreducer.js'
import { cartreducer } from './Reducers/CartReducer.js/Cartreducer.js';
import { UserDataReducer, UserDetailsReducer } from './Reducers/UserReducers/UserReducers.js';
import { RegisteringDataReducer } from './Reducers/RegisteringReducers/RegisteringReducers.js';
import { OrderDataReducer } from './Reducers/OrderReducer/OrderReducers.js';
const cartitemsfromstorage=localStorage.getItem('cartitems') ? JSON.parse(localStorage.getItem('cartitems')) :[]
const userdetailsfromstorage=JSON.parse(localStorage.getItem('userdetails')) ;
const shippingdetailsfromstorage=localStorage.getItem('shippingdetails')  ? JSON.parse(localStorage.getItem('shippingdetails')) :"";
const initialstate={

    cartdata:{cartitems:cartitemsfromstorage,shippingdetails:shippingdetailsfromstorage},
    userdata:{userdetails:userdetailsfromstorage}
};
const reducers=combineReducers({
Productdata:ProductDataReducer,
Singleproductdata:singleproductreducer,
cartdata:cartreducer,
userdata:UserDataReducer,
Registerdata:RegisteringDataReducer,
Userdetailsdata:UserDetailsReducer,
orderdata:OrderDataReducer



});
const middleware=[thunk]

const store=createStore(reducers,initialstate,composeWithDevTools(applyMiddleware(...middleware)));


export default store;
