import Order from '../models/Ordermodel.js';
const creatingOrder=async(req,res)=>{
const {OrderedList,Shippingaddress,payment,tax,shippingprice,totalprice,cartitemsprice}=req.body;


if(OrderedList && OrderedList.length==0){
    res.status(400)
    throw new Error("No items ordered")
    return ;
}
else{
    const order=new Order({
        OrderedList,
        user:req.user._id,
        Shippingaddress,
        payment
        ,tax
        ,shippingprice
        ,totalprice,
        cartitemsprice
    })
    const neworder=await order.save()
    res.status(201).json(order)
}
}
export {creatingOrder}
