import axios from 'axios';
import React, { useState,useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom'
import { recommendabook } from '../Actions/RecommendationAction/RecommendationAction';
import { bookreview } from '../Actions/ReviewActions/ReviewActions';

const SingleCard = () => {
    useDispatch();
    useState()
    const[comments,setComments]=useState("")
    const{id}=useParams();
    const[singlebookdata,setSinglebookdata]=useState([]);
    useEffect(() => {
      axios.get(`http://localhost:8001/products/${id}`)
    .then(res=>setSinglebookdata(res.data))
      
    }, [])
    const dispatch=useDispatch()
    console.log(singlebookdata.reviews)
    const userdata=useSelector(state=>state.userdata);
    const{userdetails,error}=userdata;
let singledet=singlebookdata.reviews;
    const reviewdata=useSelector((state)=>state.reviewdata);
    const{error:reviewerror,success,review}=reviewdata
    console.log(review)
    // const display=(review)=>(
    //     // <div key={review._id}>
    //     // <p>{review.Name}</p>
    //     // </div>
    // )
         
         const data={ 
             user:userdetails._id,
             Name:singlebookdata.Name,
            Author:singlebookdata.Author,
            Img:singlebookdata.Img,
            Category:singlebookdata.Category,
            Language:singlebookdata.Language,
            Description:singlebookdata.Description
            }

    const recommend=(singlebookdata)=>{
    dispatch(recommendabook(data))}
   
 
  return (
    <div>
                <div className="container">

                <div class="card">
                <img src={singlebookdata.Img} className="card-img-top img-fluid" style={{width:"300px",height:"300px"}}alt="..."/>

  <div class="card-header">
    {singlebookdata.Name}
  </div>
  <div class="card-body">
    <h5 class="card-title">Author{singlebookdata.Author}</h5>
    <p class="card-text">Description{singlebookdata.Description}.</p>
    <p class="card-text">Category{singlebookdata.Category}.</p>
    <p class="card-text">Language{singlebookdata.Language}.</p>
    <button className='btn btn-primary'onClick={()=>recommend(singlebookdata)}>reccomend</button>  </div>

  </div>
</div>
    
      
            <div>
                {/* {reviews.map((review)=>{
                    display(review);
                })} */}

</div>
</div>
)}

export default SingleCard