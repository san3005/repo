import React,{useEffect,useState} from 'react'
import { Navigate, NavLink, useParams,useNavigate } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios"
import './Cart.css'
import { useDispatch, useSelector } from 'react-redux';
import { cartad ,cartdelete} from '../../Actions/CartAction/CartAction';

const Cart = () => {
  const{id}=useParams();
  console.log(id);
  const{qtyy}=useParams();
  console.log(qtyy)
const cart=useSelector((state)=>state.cartdata);
const userdata=useSelector(state=>state.userdata);
const{userdetails,error}=userdata;
const{cartdata}=cart;
const allitems=  cart.cartitems
console.log(allitems)
const[total,setTotal]=useState(0)
  const dispatch=useDispatch()
  const navigate=useNavigate()

  useEffect(() => {
   if(id){
     dispatch(cartad(id,qty))
     //passing the action id qty got from use params
   }
  
    
  }, [])
  const handlecheckout=()=>{
    if(userdata.userdetails){
navigate("/shipping")
    }else{
    navigate("/signin")}
    // axios.put(`http://localhost:8001/Econ1/products/${singlecartitem.product}`)
  }
  const handleplusqty=(s)=>{

    dispatch(cartad(s.product,s.qty+1))

}

const handleminusqty=(s)=>{
const minusqty=(s.qty)-1;
const singleid=(s.product);
console.log(singleid);
dispatch(cartad(s.product,s.qty-1))
console.log(s.qty-1)

  }
  let r=0;
let d;
console.log(d);
const handledelete=(singlecartitem)=>{
  console.log(singlecartitem.product);
  dispatch(cartdelete(singlecartitem.product))
  toast.dark('deleted',{
    theme:'dark'
  })
}
 const display=(singlecartitem)=>(
   
      <div className="row gx-2">
        <div className="col-12">
        <div class="card my-3">

          <div className="row">
        <div className="col-2">

      {
  }
    <div className="card-img mx-2 ">
  <img src={singlecartitem.Img} style={{marginLeft:"20%"}}className="img-fluid" />
  </div>
  </div>
  <div className="col-4 ">


  <div class="card-body" >

<p>{singlecartitem.Name}</p>
    
    <p>₹{singlecartitem.Price}</p>

   {/* {
    console.log(singlecartitem)}
    <select value={qty} onChange={(e)=>dispatch(cartad(singlecartitem.product,Number(e.target.value)))}>
    {[...Array(singlecartitem.CountInstock).keys()].map((option)=>(
      <option key={option+1} value={option+1}>{option}</option>
    ))} 

    </select> */}
  </div>
  </div>
  <div className="col-4 mt-4 addbuttons">

<button className="btn btn-dark btn-sm mx-4 my-5 " onClick={()=>handleminusqty(singlecartitem)} disabled={singlecartitem.qty<=1}>-</button>
{singlecartitem.qty} 

<button className='btn btn-dark btn-sm mx-4 my-5' onClick={()=>handleplusqty(singlecartitem)} disabled={singlecartitem.qty===singlecartitem.CountInstock}>+</button>
</div>

<div className="col-2 " style={{marginTop:"30px"}}>
<i class='bx bxs-trash trashcan' onClick={()=>handledelete(singlecartitem)} style={{fontSize:"18px",cursor:"pointer"}}></i>
</div>
</div>
</div>
</div>

</div>
  )


const n=allitems.reduce((total,s)=>total+s.qty*s.Price,0)

  const{qty}=useParams();
  console.log(qty);
  const k=()=>{
    toast.dark("Added to cart",{

    })
  }
  return (
    <>
        {allitems.length >0 ?(
    <div className="container">
              <NavLink to="/" className=" card_button mx-4 px-2 py-2" style={{textDecoration:"none"}}>Go back</NavLink>

      <div className="row mx-4 my-4">
<div className='col-6 '>
  <h4 className='subtotal'>Subtotal<span style={{color:"red"}}>₹{n}</span></h4>
   
</div>
<div className="col-4 ">
<h4><button className="btn btn checkout" onClick={handlecheckout}>Checkout</button></h4>
{/* <NavLink to="/login?redirect=shopping">tu</NavLink> */}
</div>
</div>
<div className="row">

<div className="col-12 mx-3">

{
  allitems.map(singlecartitem=>

display(singlecartitem))
}

      <ToastContainer  />
      </div>


</div>

    </div>)
  :(
    <h1>The Cart is  Empty ,We got some good stuff you could buy</h1>
  )}
 </>
 )
}

export default Cart