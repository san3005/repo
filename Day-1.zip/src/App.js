import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Home from './Home';
import About from './About';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';

function App() {
  return (
    <>
    <div  style={{minHeight:"90vh"}}>

    <Router>

      <Routes>
        <Route path="/" element={<Header/>}/>
        <Route path="/about" element={<About/>}/>


      </Routes>
{/* <marquee>grab the offer right now offer ends in tomorrow</marquee> */}
    </Router>
    <ProductCard/>

    </div>

        <Footer/>
</>
  );
}

export default App;
