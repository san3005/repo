import React from 'react'
import { NavLink } from 'react-router-dom'

const Checkout = ({step1,step2,step3,step4}) => {
  return (
    <nav className='nav justify-content-center mb-4'>
<div className='nav-link'>{step1 ? (
<NavLink to="/signin" >signin</NavLink>
):(
    <NavLink to="/" ><button disabled> Sign in </button></NavLink>
)}
</div>
<div className='nav-link'>{step2 ? (
<NavLink to="/shipping" >shipping</NavLink>
):(
    <NavLink to="/" ><button disabled>  Shipping</button></NavLink>
)}
</div>
<div className='nav-link'>{step3 ? (
<NavLink to="/payment" >payment</NavLink>
):(
    <NavLink to="/" ><button disabled> Payment </button></NavLink>
)}
</div>
<div className='nav-link'>{step4 ? (
<NavLink to="/placeorder" >pLACE Order</NavLink>
):(
    <NavLink to="/" ><button disabled> Place order</button></NavLink>
)}
</div>
    </nav>
  )
}

export default Checkout