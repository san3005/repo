import React,{useState} from 'react'
import {Link} from 'react-router-dom'
import './index.css'

const Header = () => {

  const [show,setShow]=useState(false);
  const toggle=()=>{

    return setShow(!show);
  }
  return (
    <div className='container'>
      <div className="navbar">
        <div className="logo">
          
          <span className="iconify" data-icon="simple-icons:nike" style={{color: "black"}}></span>
        </div>
        <div className={show ? "links active" : "links"}>
        <Link onClick={()=>toggle()} to="/">Home</Link>
        <Link onClick={()=>toggle()}to="/">Details</Link>
        <Link onClick={()=>toggle()}to="/about">Signin <i className='bx bx-user ter' ></i></Link>
        <Link onClick={()=>toggle()}to="/about">about</Link>
        </div>
        <div className={show ?'bars-button active' : 'bars-button'} onClick={()=>toggle()}>
        <span></span>
        <span></span>
        <span></span>
        </div>
      </div>


    </div>
  )
}

export default Header