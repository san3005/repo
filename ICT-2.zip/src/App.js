import './App.css';
import { useState,useEffect } from 'react';
import axios from "axios";



function App() {
  
  const [selectedclass,setSelectedclass]=useState("");
  const[selectedperformance,setSelectedperformance]=useState("")
  const [choices,setChoices]=useState([]);
  const [performancechoices,setPerformancechoices]=useState([]);
  const[buttonclicked,setButtonClicked]=useState(false)
  const [details,setDetails]=useState([]);
  const[handleleft,setHandleleft]=useState(false);
  const[handleright,setHandleright]=useState(true);

  
  
  
  //getting class dropdown values
  useEffect(() => {
  axios.get("http://localhost:8000/classDropdown")
  .then((response)=>setChoices(response.data))
  }, []);
//getting performance dropdown values
  useEffect(() => {
axios.get("http://localhost:8000/performanceLevel")  
.then((res=>setPerformancechoices(res.data)))
   
  }, []);
  //getting whole class details
  useEffect(() => {
    axios.get("http://localhost:8000/classes")  
    .then((res=>{setDetails(res.data);
  }))
       
      }, []);

const arrowclickedright=(e)=>{
  setHandleleft(true);
  setHandleright(false);
}
const arrowclickedleft=(e)=>{
  setHandleleft(false);
  setHandleright(true);
}
  let classsdropdown =choices.map(choice => 
    <option key={choice} >{choice}</option>);
  
  
    let performancedropdown=performancechoices.map(performancechoice=>
      <option key={performancechoice}>{performancechoice}</option>);
   
      let selected=selectedclass;
      let splittedclass = selected.split(" ")
      let integerclass=(splittedclass[1]);
     
    
        
    const tabledata=(singlestudent,data,i)=>{
      if(data.className==integerclass){
  if(singlestudent.peformanceLevel===selectedperformance){
        if(buttonclicked)
        {

return(
<> 
<tr className={i%2==0 ?"even" :"odd"} key={data.className}>
     <td>{singlestudent.studentName}</td>
     <td>{singlestudent.rank}</td>
        <td><i className={"fas fa-circle "+ (singlestudent.peformanceLevel=="Above-Level" ? "aboveLevel" : "")+
(singlestudent.peformanceLevel=="Below-Level" ? "belowLevel":"")+(singlestudent.peformanceLevel=="On-Level" ?"onLevel" :"")}></i>{singlestudent.completedPercent}{singlestudent.peformanceLevel}</td>
        <td>{singlestudent.mid1Score}</td>
        <td className={handleleft ?"hide1":"display1"}>{singlestudent.mid2score}</td>
        <td className={handleright ?"hide3":"display3"}>{singlestudent.finalscore}</td>
        </tr>  
</> 
        
)
}}
}
         
}

   
  return (
    <div className="App">
           <h1 className='mb-3'>Student Progress Report</h1>
                <select id="classdropd"  className='dropdown-class ' onClick={(e)=>setSelectedclass(e.target.value)} >
                <option>Select Class</option>
                {classsdropdown}
                </select>
                <select id="performancedropd" className="dropdown-performance"onClick={(e)=>setSelectedperformance(e.target.value)}>
                <option>Select Level</option>
  {performancedropdown}
                </select>
                <button type="button"  onClick={(e)=>setButtonClicked(true)}  className="btn btn-outline-info">Get Report</button>

                <p className='classresults'>Class Results</p>
                <div className='line'></div>

  <table className="table">
  <thead style={{borderBottom:"4px solid orange"}}>
    <tr >
      <th scope="col">Student Name</th>
      <th  scope="col">Rank</th>
      <th  scope="col">Performance Level</th>
      <th scope="col">MID1SCORE <br/>OUT OF 600</th>
      <th className={handleleft ? "hide2":"display2"} scope="col">MID2 SCORE <br/>OUT OF 600</th>
      <th className={handleright ? "hide4":"display4"} scope="col">FINAL SCORE <br/> OUT OF 600</th>

      <th> <div className='arrow-left'><box-icon  name='chevron-left'onClick={(e)=>arrowclickedleft(e)} ></box-icon></div></th>
      <th>  <div className='arrow-right'><box-icon name='chevron-right' onClick={(e)=>arrowclickedright(e)}></box-icon></div></th>
    </tr>
  </thead>
  <tbody>
    {
(details.map((data)=>(
    data.studentresults.map((singlestudent,i)=>(
tabledata(singlestudent,data,i)  
     )))))}  </tbody>
</table>
                </div>
);
    

};

export default App;

