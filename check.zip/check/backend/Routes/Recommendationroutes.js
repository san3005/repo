import express from 'express';
const router=express.Router();
 import {getrecommendationlist,recommendbook} from '../Controllers/RecommendationListControllers.js'
import { protectede } from '../Middleware/Authentication.js';



router.post("/",protectede,recommendbook)
router.get("/recommended",protectede,getrecommendationlist);

export default router;