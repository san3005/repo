import React, {useEffect} from 'react'
import { useDispatch ,useSelector} from 'react-redux'
import { recommendlist } from '../../Actions/RecommendationAction/RecommendationAction';

const Recommendation = () => {
    const dispatch=useDispatch();
    useEffect(() => {
      
    dispatch(recommendlist())
    
    }, [])
    const userdata=useSelector(state=>state.userdata);
    const{userdetails}=userdata;
    const recommendationlistdata=useSelector(state=>state.recommendationlistdata);
    const{recommended,error}=recommendationlistdata;
  return (
    <div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Book Name</th>
      <th scope="col">Author</th>
      <th scope="col">Description</th>
      <th>Recommended by</th>
    </tr>
  </thead>
  <tbody>
   {recommended.data==null 
 ? "Loading..."
:
      ( recommended.data.map((s,i)=>(
           <tr key={i}>
               <td>{i+1}</td>
               <td>{s.Name}</td>
               <td>{s.Author}</td>
               <td>{s.Description}</td>
               <td>{userdetails.Name===s.username ?("me"):s.username}</td>
           </tr>
       ))
      )}
  </tbody>
</table>

    </div>
  )
}

export default Recommendation