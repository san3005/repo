import jwt from 'jsonwebtoken';
const generatenewtoken=(id)=>{
return jwt.sign({id},process.env.JWT_TOKEN,
    {expiresIn:'30d'})
}
export default generatenewtoken;