import FavList from '../Models/FavlistModel.js';
const creatingfavlist=async(req,res)=>{
const {Favbook}=req.body;


if(Favbook && Favbook.length==0){
    res.status(400)
    throw new Error("No fav books")
    return ;
}
else{
    const favlist=new FavList({
        Favbook,
        user:req.user._id,
    })
    const newfavlist=await favlist.save()
    res.status(201).json(favlist)
}
}

// const recommendationlist=async(req,res)=>{
//     const recommended=await Order.find({})
// }
   
    const myfavlist=async(req,res)=>{
        const favlist=await FavList.find({user:req.user._id})
res.json(favlist)
    }


export {creatingfavlist,myfavlist}
