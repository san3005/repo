const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const HandsonSchema=new Schema({

employee_name:{
    type:String,
    required:true
},
employee_age:{
    type:Number,
    required:true,
},
employee_salary:{
    type:Number,
    required:true
}


})
const Handson=mongoose.model("Handson",HandsonSchema);
module.exports=(Handson);
// const mongoose=require('mongoose');
// const Schema=mongoose.Schema;
// const TodoSchema=new Schema({
//     text:{
//         type:String,
//         required:true
//     },
//     complete:{
//         type:Boolean,
//         default:false
//     },
//     timestamp:{
//         type:String,
//         default:Date.now()

//     }
// })
// const Todo=mongoose.model("Todo",TodoSchema);
// module.exports=(Todo);