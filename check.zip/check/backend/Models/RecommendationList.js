import mongoose from 'mongoose';
const Schema=mongoose.Schema;
const RecommendationListSchema = new Schema({
    user:{
type:mongoose.Schema.Types.ObjectId,
ref:'User'
    },

  username:{
      type:String
  },

       
Name:{
    type:String,

},
Author:{
    type:String
},
Img:{
    type:String,
},
Category:{
    type:String,

},
Language:{
    type:String,
},
Description:{
    type:String,

},
        product:{
            type:mongoose.Schema.Types.ObjectId,
            ref:'Product',
        }
    }
,



{
    timestamps:true
}

)




const RecommendationList=mongoose.model("RecommendationList",RecommendationListSchema);
export default RecommendationList;