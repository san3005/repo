const exp = require("express")
const app = exp();
const exphdb = require("express-handlebars")

var hp = require("handlebars-paginate")
var hbs = exphdb.create({ });
app.engine('handlebars', hbs.engine)

app.set('view engine', 'handlebars')

hbs.handlebars.registerHelper('paginate', require('handlebars-paginate'));
const emps =  require("./Data.json")


app.get("/", (req, res) => {

   
    let e=emps.data;
    var empscopy = [...e]
   
    let currentPage;
    if (req.query.p == undefined) {
        currentPage = 1;
    }
    else {
        currentPage = (+ req.query.p);
    }
    let size = 6;
    let skip = ((+req.query.p) -1) * size;

   

    let selectedEmp = empscopy.splice(skip, size)

    emps.data.splice()
    res.render('employee', {
        pagination: {
            page: currentPage,
            pageCount: 5,
            emps: selectedEmp
        }
    })
})

app.listen(8080, () => { console.log("server on 8080") })
