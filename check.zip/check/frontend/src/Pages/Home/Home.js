import React from 'react'
import { useParams } from 'react-router-dom'
import Card from '../../Components/Card'

const Home = () => {
    const{words}=useParams()

  return (
    <div>
        <Card words={words}/>
    </div>
  )
}

export default Home