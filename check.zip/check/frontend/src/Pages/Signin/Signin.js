import React,{useEffect,useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { NavLink,Link,useLocation , useNavigate} from 'react-router-dom'
import { userlogin } from '../../Actions/UserAction/UserActions';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Signin.css'

const Signin = () => {
  const location=  useLocation();
    const dispatch=useDispatch();
    const navigate=useNavigate()
    const userdata=useSelector(state=>state.userdata);
    const{userdetails,error}=userdata;
    console.log(userdetails);
    const[email,setEmail]=useState("");
    const[password,setPassword]=useState("");
    // const redirect=location.search?location.search.split("")[1]:"/cart";
    useEffect(() => {
      if(userdata.userdetails){
    
      }  
          }, [])
    const handlesubmit=(e)=>{
        e.preventDefault();
        dispatch(userlogin(email,password));

navigate("/home")
}
const redirectinghandler=()=>{
  if(userdata.userdetails){
    navigate(-1)

  }  
}

  return (
      <>
    {error ? (<div className="alert alert-danger" role="alert">
    {error}
    </div>):("")}
<div className="container4">
 


	<div className="screen">
		<div className="screen__content">
			<form className="login1" onSubmit={(e)=>handlesubmit(e)}>
				<div className="login__field">
                <i className="login__icon bx bxl-gmail"></i>
					<input type="text" className="login__input"placeholder="  Email" value={email} onChange={(e)=>setEmail(e.target.value)}/>
                    
            	</div>
				<div className="login__field">
					<i className="login__icon fas fa-lock"></i>
					<input type="password" className="login__input" placeholder="Password"  value={password} onChange={(e)=>setPassword(e.target.value)}/>
                    {/* value={Password} */}
				</div>
				<button className="button login__submit" >
					<span className="button__text" onClick={redirectinghandler()}>Log In Now</span>
					<i className="button__icon fas fa-chevron-right"></i>
				</button>		
		
			</form>
           <h6> <NavLink to="/register" className="text-dark "style={{marginLeft:"30px",textDecoration:"none"}}>Create Account</NavLink></h6>
           
<ToastContainer style={{zIndex:"200"}}/>
		</div>
		<div className="screen__background">
			<span className="screen__background__shape screen__background__shape4"></span>
			<span className="screen__background__shape screen__background__shape3"></span>		
			<span className="screen__background__shape screen__background__shape2"></span>
			<span className="screen__background__shape screen__background__shape1"></span>
		</div>		
	</div>
</div>  


</>
// {<>
//     "NewCustomer" ? 
//      <NavLink to={redirect?`/register?redirect=${redirect}`}>Register </NavLink>
    
//      :"/"
//      </> 
//     } 
  )
}

export default Signin