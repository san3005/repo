import express from 'express';
const router=express.Router();
import Cart from '../models/Cartmodel.js'

router.get("/",async(req,res)=>{
    const data=await Cart.find();
    // console.log(data);
    res.json(data)
})
// router.put("/edit/:id",(req,res)=>{
//     Cart.findByIdAndUpdate(req.params.id,{
//         $set:req.body
    
//     },
//         (error,data)=>{
//             if(error){
//             return (error)}
//             else{
//                 res.json(data);
//                 console.log(data)
//             }
//         }
//     )})
export default router;
