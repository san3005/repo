
import bcryptjs from 'bcryptjs'

const users=[
    {
        Name:"san3005",
        Email:"san3@gmail.com",
        Password: bcryptjs.hashSync("123456",20),
        IsAdmin:true
        },
        {
            Name:"user1",
            Email:"user1@gmail.com",
            Password: bcryptjs.hashSync("123456",20 ),
        }
]
export default users