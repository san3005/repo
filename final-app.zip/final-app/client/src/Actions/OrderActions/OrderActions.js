import axios from "axios";
import {  toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export const creatingorder=(order)=>async(dispatch,getState)=>{
        try{
            const {userdata:{userdetails}}=getState()
    console.log(userdetails.token);
    console.log(order);
            const config={
    headers:{
    "Content-Type":"application/json",
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const data= await axios.post("http://localhost:8001/orders",order,config)
    console.log(data);

            dispatch({
               type:'ORDER_SUCCESS',
               payload:data
    
            })
        //     dispatch({
        //         type:'MY_ORDER_SUCCESS',
        //         payload:data
     
        //      })

            toast.success("order placed redirecting you to home page ")
            localStorage.removeItem("cartitems")
            localStorage.removeItem('shippingdetails')
            localStorage.removeItem('paymentmethod')

    
        }
        catch(error){
    dispatch({type:'ORDER_FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }

    export const singleorder=(id)=>async(dispatch,getState)=>{
        try{
            const {userdata:{userdetails}}=getState()
    console.log(userdetails.token);
    console.log(id);
            const config={
    headers:{
        "Content-Type":"application/json",
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const data= await axios.get(`http://localhost:8001/orders/${id}`,config)
    console.log("singleorder",data);
    
            dispatch({
               type:'ORDER_DETAILS_SUCCESS',
               payload:data
    
            })
           
        //     localStorage.removeItem("cartitems")
        //     toast.success("order placed")

    
        }
        catch(error){
    dispatch({type:'ORDER_DETAILS__FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }
    export const myorder=()=>async(dispatch,getState)=>{
        try{
            const {userdata:{userdetails}}=getState()
            const config={
    headers:{
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const data= await axios.get(`http://localhost:8001/orders/myorders`,config);
    console.log("singleorder",data);
    
            dispatch({
               type:'MY_ORDER_SUCCESS',
               payload:data
    
            })
           
            localStorage.removeItem("cartitems")
        //     toast.success("order placed")

    
        }
        catch(error){
    dispatch({type:'MY-ORDER_FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }


    export const allorders=()=>async(dispatch,getState)=>{
        try{
            dispatch({
                type:'ALL_ORDER_REQUEST',
            })
            const {userdata:{userdetails}}=getState()
            const config={
    headers:{
    Authorization:`Bearer ${userdetails.token}`
    }
            }
            const {data}= await axios.get(`http://localhost:8001/orders/totalorders`,config);
    // console.log("allorder",data);
    
            dispatch({
               type:'ALL_ORDER_SUCCESS',
               payload:data
    
            })
           
        //     toast.success("order placed")

    
        }
        catch(error){
    dispatch({type:'ALL_ORDER_FAILED',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }
    export const deleteorder=(id)=>async(dispatch,getState)=>{
    
        try{
    
            dispatch({
                type:'ORDER_DELETE_REQUEST'
            })
           
            const {userdata:{userdetails}}=getState()
            console.log(userdetails.token);
                    const config={
            headers:{
                "Content-Type":"application/json",
            Authorization:`Bearer ${userdetails.token}`
            }
            }
        await axios.delete(`http://localhost:8001/orders/delete/${id}`,config)
            dispatch({
               type:'ORDER_DELETE_SUCCESS',
    
            })
    
        }
        catch(error){
        dispatch({type:'ORDER_DELETE_FAIL',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }
    
    export const updateorder=({id,IsDelivered})=>async(dispatch,getState)=>{
        try{
    
            dispatch({
                type:'ORDER_UPDATE_REQUEST'
            })
           
            const {userdata:{userdetails}}=getState()
                    const config={
            headers:{
                "Content-Type":"application/json",
            Authorization:`Bearer ${userdetails.token}`
            }
            }
            const data= await axios.put(`http://localhost:8001/orders/updateorder/${id}`,{IsDelivered},config)
            
            console.log("updatedorder",data);
         
            dispatch({
                type:`ORDER_UPDATE_SUCCESS`,
                payload:data,
            })
    
        }
        catch(error){
        dispatch({type:'ORDER_UPDATE_FAIL',
            payload:error.response && 
            error.response.data.message ? error.response.data.message:error.message})
    
        }
    }
    