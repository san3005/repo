import axios from "axios";

export const recommendabook=(book)=>async(dispatch,getState)=>{
    try{
        const {userdata:{userdetails}}=getState()
console.log(userdetails.token);
console.log(book);
        const config={
headers:{
"Content-Type":"application/json",
Authorization:`Bearer ${userdetails.token}`
}
        }
        const data= await axios.post("http://localhost:8001/recommendedlist",book,config)
console.log(data);

        dispatch({
           type:'RECOMMENDATION_SUCCESS',
           payload:data

        })
    //     dispatch({
    //         type:'MY_ORDER_SUCCESS',
    //         payload:data
 
    //      })



    }
    catch(error){
dispatch({type:'RECOMMENDATION_FAILED',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}

export const recommendlist=()=>async(dispatch,getState)=>{
    try{
        const {userdata:{userdetails}}=getState()
console.log(userdetails.token);
        const config={
headers:{
Authorization:`Bearer ${userdetails.token}`
}
        }
        const data= await axios.get("http://localhost:8001/recommendedlist/recommended",config)

        dispatch({
           type:'RECOMMENDATION_LIST_SUCCESS',
           payload:data

        })
    //     dispatch({
    //         type:'MY_ORDER_SUCCESS',
    //         payload:data
 
    //      })



    }
    catch(error){
dispatch({type:'RECOMMENDATION_LIST_FAILED',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}

