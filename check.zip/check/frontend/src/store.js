import {createStore,combineReducers,applyMiddleware} from 'redux'
import thunk from 'redux-thunk';
import {composeWithDevTools} from '@redux-devtools/extension';
import { UserDataReducer, UserDetailsReducer } from './Reducers/UserReducers/UserReducers.js';
import { RegisteringDataReducer } from './Reducers/RegisteringReducers/RegisteringReducers.js';
import { OrderDataReducer, OrderDetailsDataReducer, OrderUserDataReducer } from './Reducers/OrderReducer/OrderReducers.js';
import { ReviewDataReducer } from './Reducers/ReviewReducer/ReviewReducers.js';
import { RecommendationDataReducer, RecommendationListDataReducer } from './Reducers/ReccomendationReducer/Recommendationreducer.js';
const userdetailsfromstorage=JSON.parse(localStorage.getItem('userdetails')) ;
const initialstate={

    userdata:{userdetails:userdetailsfromstorage}
};
const reducers=combineReducers({

userdata:UserDataReducer,
Registerdata:RegisteringDataReducer,
Userdetailsdata:UserDetailsReducer,

orderdata:OrderDataReducer,
orderdetailsdata:OrderDetailsDataReducer,
orderuserdata:OrderUserDataReducer,
reviewdata:ReviewDataReducer,
recommendationdata:RecommendationDataReducer,
recommendationlistdata:RecommendationListDataReducer
});
const middleware=[thunk]

const store=createStore(reducers,initialstate,composeWithDevTools(applyMiddleware(...middleware)));


export default store;
