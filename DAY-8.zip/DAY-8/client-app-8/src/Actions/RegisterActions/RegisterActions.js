import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { userlogin } from "../UserAction/UserActions";

export const Registering=(name,email,password)=>async(dispatch)=>{
    try{

        const config={
headers:{
"Content-Type":"application/json"
}
        }
        const {data}= await axios.post("http://localhost:8001/users/Registration",{"Email":email,"Password":password,"Name":name},config)
console.log(data);
        dispatch({
           type:'REGISTRATION_SUCCESS',
           payload:data

        })
        dispatch({
            type:'USER_LOGIN',
            payload:data
 
         })
         localStorage.setItem("userdetails",JSON.stringify(data));
         toast.success('Registration success')


    }
    catch(error){
    dispatch({type:'REGISTRATION_FAILED',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})

    }
}
