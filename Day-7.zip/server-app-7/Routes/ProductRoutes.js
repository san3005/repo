import express from 'express';
const router=express.Router();
 import {getProduct,getProducts} from '../controllers/ProductControllers.js'



router.get("/",getProducts);

router.get("/:id",getProduct);

// router.delete("/delete/:id",async(req,res)=>{
//     const data= await Product.findByIdAndDelete(req.params.id)
//     res.json(data);
// })
// {"_id":{"$oid":"621e0a8195a3db08eced600a"},"Img":"/Images/img1.png","user":"621e097d5837871f94d4a0fd","Name":"Audra.Heidenreich","Price":63,"reviews":[{"Name":"Rylan_Hand","Rating":38,"Comments":" Cathryn67"}],"Category":"Children","Description":"Llewellyn_Auer","CountInStock":46,"NumberofReviews":35,"Rating":3.2,"updatedAt":{"$date":"2022-03-05T04:49:58.392Z"}}
// router.post("/add",async(req,res)=>{
//     const product= new Product({
//         req.body
//     });
// })
// router.put("/edit/:id",  (req,res)=>{
//     const
//         // user,
//         // Name,
//         // Price,
//         // Category,
//         // Description,
//         CountInStock
//     =req.body
//     const product= Product.findById(req.params.id)
//     if(product){
//         // product.user,
//         // product.Name,
//         // product.Price,
//         // product.Category,
//         // product.Description,
//         product.CountInStock
    
//    product.save()
//     res.json("updatedproduct")
// }
//     else{
//         res.status(404)
//         throw new Error('product not found')

//     }})
// router.post("/edit/:id",(req,res)=>{
//     Product.findByIdAndUpdate(req.params.id),
//     const{CountInStock}=req.body;
// res.send({CountInStock})

//         (error,data)=>{
//             if(error){
//             return (error)}
//             else{
//                 res.json(data);
//                 console.log("updated bro")
//             }
//         }
//     )}


// router.route("/edit/:id").post((req,res)=>
// Product.findById(req.params.id)
// .then(product =>{
//     product.CountInStock=req.body.CountInStock;
//     product.save()
//     .then(()=>res.json("updated"))
//     .catch(err=>res.status(400).json('error'+err));

// })
// .catch(err=>res.status(400).json('error'+err))
// );
// router.put('/edit/:id',(req,res)=>{
//     Product.findByIdAndUpdate(req.params._id,{
//         CountInStock:req.body.CountInStock || 5000
//     })
//     res.json('updated')
// })
export default router;