import RecommendationList from "../Models/RecommendationList.js";
const recommendbook=async(req,res)=>{
    const book=await new RecommendationList({
        user:req.user._id,
        username:req.user.Name,
        Name:req.body.Name,
        Author:req.body.Author,
        Img:req.body.Img,
        Category:req.body.Category,
        Language:req.body.Language,
        Description:req.body.Description,

    })
    book.save();
    res.json(book);


}
const getrecommendationlist=async(req,res)=>{
const book=await RecommendationList.find({})
res.json(book)
}
export{getrecommendationlist,recommendbook}