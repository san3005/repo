import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Navigate, NavLink, useNavigate } from 'react-router-dom'
import { creatingorder } from '../../Actions/OrderActions/OrderActions.js'
import Checkout from './Checkout'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const PlaceOrder = () => {
  
 
 
  const dispatch=useDispatch();
  const navigate=useNavigate()
  const cart=useSelector((state)=>state.cartdata);
  const orderdata=useSelector((state)=>state.orderdata);
  const{order,error,success}=orderdata

  
// const[tada,setTada]=useState('')
  const{shippingdetails,paymentmethod}=cart;

  cart.cartitemsprice=cart.cartitems.reduce((total,s)=>total+s.qty*s.Price,0)
  cart.shippingprice=Number(cart.cartitemsprice>100 ? 250 :150)
  cart.tax=Number(cart.cartitemsprice>150?50:100)
cart.totalprice=Number(cart.cartitemsprice+cart.shippingprice+cart.tax)
const checkouthandler=()=>{

  dispatch(creatingorder({
    OrderedList:cart.cartitems,
    Shippingaddress:shippingdetails,
    payment:cart.paymentmethod.paymenttype,
    tax:cart.tax,
    shippingprice:cart.shippingprice,
    totalprice:cart.totalprice,
    cartitemsprice:cart.cartitemsprice
  
  }))    
      }
      
      
      useEffect(() => {
        if(success){
          // navigate(`/order/$order._id`)

navigate("/")        }
      
        return () => {
          
        }
      }, [])
      
  return (
<>
<ToastContainer/>
   <div className=' container my-3'>
      <div className="row">

          <Checkout step1 step2 step3 step4/> 
<div className="row">
  <div className="col-6">
<h1>Address</h1>
<p style={{fontSize:"24px"}}>
Name:{shippingdetails.name},<br/>Addrress:
<em>{shippingdetails.address}</em>,<br/>
City:{shippingdetails.city},<br/>
State:{shippingdetails.states},<br/>
ZipCode:{shippingdetails.zipcode}
 </p> </div>
<div className='col-6'>
<h2>Order summary</h2>
<p>Price=₹{cart.cartitemsprice}</p>
<p>ShippingPrice=₹{cart.shippingprice}</p>
<p>Customs tax=₹{cart.tax}</p>
<p>TotalPrice=₹{cart.totalprice}</p>
<div >
  {error && 
  <div class="alert alert-danger" role="alert">
{error}</div>}
<button className=''style={{color:"green"}} onClick={checkouthandler} disabled={cart.cartitems.length==0}>checkout</button>
</div>
<div>
</div>
</div>
</div>
<hr />
{/* sometimes after reloading showing error */}
<h3>Payment Method:{paymentmethod.paymenttype}</h3>

  <h2>Ordered Items</h2>
  {cart.cartitems.length==0 ? (<p>Your Cart is empty</p>):
    (cart.cartitems.map((singleitem,index)=>(
      <>
      <div className="container" key={singleitem.product}>

          <div className="card my-3" style={{width:"32rem"}}>
          <div className="row my-2">

<div className="col-3 my-2">

        <img src={singleitem.Img} style={{marginLeft:"20%",width:"30px",height:'30px'}}className="img-fluid " />
        </div>
        <div className="col-4">
<NavLink to={`/products/${singleitem.product}`} style={{textDecoration:"none",color:"#000"}}>{singleitem.Name}</NavLink>
</div>
<div className="col-4">
  {singleitem.qty} x {singleitem.Price}={singleitem.qty*singleitem.Price}
</div>
        </div>
        </div>

      </div>
      <div className="col-4">
      </div>
      </>
    )))
  }
        </div>
        </div>


</>
  )
}

export default PlaceOrder