import React,{useState,useEffect} from 'react'
import { NavLink } from 'react-router-dom'
import './Card.css'

const Card = ({product}) => {
    return (
    <div className='singleproduct '>
<div className="container mt-5 ">
<div className='card '>
    <img src={product.img} className='card_img'/>
<div className="card_data">
  <div className="card_title">
{product.name}  </div>
  <span className="card_price">{product.price}</span>
  <p className="card_description">Nike Air jordan footwear basketabll sneakers</p>
  <button className="btn btn card_button">
      {/* <NavLink to={`/products/${product._id}`}>
          Buy Now </NavLink> */}
  Buy now</button>
</div>
 </div>
 </div>

</div>
   
  )
}

export default Card