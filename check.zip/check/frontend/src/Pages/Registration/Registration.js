import React,{useEffect,useState} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { NavLink,Link,useLocation , useNavigate} from 'react-router-dom'
import { userlogin } from '../../Actions/UserAction/UserActions';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Registering } from '../../Actions/RegisterActions/RegisterActions';

const Registration = () => {
    const dispatch=useDispatch();
    const navigate=useNavigate()
    const userdata=useSelector(state=>state.userdata);
    const{userdetails,error}=userdata;
    console.log(userdetails);
    const[name,setName]=useState("");
    const[email,setEmail]=useState("");
    const[password,setPassword]=useState("")
    const[confirmpassword,setConfirmpassword]=useState("");
    const[errormsg,setErrormsg]=useState(false);
    useEffect(() => {
        if(userdata.userdetails){
          navigate("/")
      
        }
      
       
      }, [userdata])
    const handlesubmit=(e)=>{
        e.preventDefault();
        setEmail("");
        setPassword("");
        setConfirmpassword("");
        setName("");

if(password!==confirmpassword){
    setErrormsg(true);
}
else{
        dispatch(Registering(name,email,password));
        // navigate("/")

}

if(userdata.userdetails){
    // navigate("/")

  }
}
// Navigate("/cart")


const redirectinghandler=()=>{
    // if(userdata.userdetails){
    //     navigate("/cart")
    
    //   }
    }

  return (
      <>
         {error ? (<div className="alert alert-danger" role="alert">
{error}    </div>):("")}
      {/* {error  ? (<p>{error}</p>) :("")} */}
   {errormsg &&
(
    // toast.error("passwords don't match",{
    //     theme:"dark"
    // })
    <div className='alert alert-danger'>
        passwords not matching <span onClick={()=>setErrormsg(false)}>x</span>
        </div>
)}

<div className="container">

     
			<form  onSubmit={(e)=>handlesubmit(e)}>
      <div class="input-group input-group-sm mb-3">

					<input type="text" placeholder=" Name"  class="form-control" value={name} onChange={(e)=>setName(e.target.value)} required/>
             </div>       
					<input type="email" placeholder="Email"  class="form-control" value={email} onChange={(e)=>setEmail(e.target.value)} required/>
                    
					<input type="password"  placeholder="Password"  class="form-control" value={password} onChange={(e)=>setPassword(e.target.value)} minLength="6" required/>
                    {/* value={Password} */}
			
					<input type="password" placeholder="Confirm Password"  class="form-control" value={confirmpassword} onChange={(e)=>setConfirmpassword(e.target.value)} minLength="6" required/>
                    {/* value={Password} */}
				<button className="btn btn-primary" >
					<span className="button__text" onClick={redirectinghandler}>  Register Now</span>
				</button>		
		
			</form>
           <h6> <NavLink to="/" style={{marginLeft:"30px",textDecoration:"none",color:"#000"}}>Already <span style={{color:'##000'}}>have an account?</span></NavLink></h6>
           
<ToastContainer />

</div>

</>

  )
}

export default Registration