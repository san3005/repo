import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import cors from 'cors';
import path, { dirname } from 'path'
import colors from 'colors';
import ProductRoutes  from './Routes/ProductRoutes.js'
import userroutes from './Routes/UserRoutes.js'
import orderroutes from './Routes/OrderRoutes.js'
import uploadroutes from './Routes/UploadRoutes.js'
const app=express();
app.use(express.json());
app.use(cors());
dotenv.config();

app.use("/econ1/products",ProductRoutes);
app.use("/users",userroutes);
app.use("/upload",uploadroutes);
app.use("/orders",orderroutes);

mongoose.connect("mongodb+srv://SAN3005:SAN3005@cluster0.9coqr.mongodb.net/ECON12?authSource=admin&replicaSet=atlas-mfdnmj-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true",{ 
    useNewUrlParser:true,
    useUnifiedTopology:true
})
.then(()=>console.log('im connected to atlas  database bro' .underline.blue))
.catch(err=>console.log(`${err}`.underline.red ));
const __dirname = path.resolve();
console.log(__dirname)
app.use('/uploads', express.static(path.join(__dirname,'/Uploads')))

app.listen(process.env.PORT ,console.log(`Hi im up and Running good and running on ${process.env.PORT}`.blue))