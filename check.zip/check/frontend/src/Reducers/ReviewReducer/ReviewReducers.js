// export const ReviewDataReducer=(state={},action)=>{
//     switch(action.type){
//         case'REVIEW_SUCCESS':
//         return{success:true}
//         case 'REVIEW_FAIL':
//                 return{error:action.payload}
//                 default:
//                     return state
//     }
// }
export const ReviewDataReducer=(state={review:[]},action)=>{
    switch(action.type){
        case'REVIEW_SUCCESS':
        return{
review:action.payload,
            success:true
        }
        case'REVIEW_FAIL':
        return{
            error:action.payload
        }
      
        default:
            return state;
    }
    }

