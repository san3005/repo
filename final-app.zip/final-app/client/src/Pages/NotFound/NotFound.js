import React from 'react'
import { NavLink } from 'react-router-dom'

const NotFound = () => {
  return (
    <div className="container"style={{marginTop:'100px'}}>
    <h2  className="text-center"style={{fontSize:"48px",marginTop:"30px",marginBottom:"50px"}}>
      We can't find the page you are looking for.<br/>Sorry for the incovenience

    </h2>
    <NavLink to="/"  className="text-center"  style={{textDecoration:"none",fontSize:"48px",marginLeft:"40%",marginTop:"65%",color:"#fff",background:'#000',padding:"10px 20px"}}> Home</NavLink>

    </div>

  )
}

export default NotFound