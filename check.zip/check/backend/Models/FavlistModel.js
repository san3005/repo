import mongoose from 'mongoose';
const Schema=mongoose.Schema;
const FavListSchema = new Schema({
    user:{
type:mongoose.Schema.Types.ObjectId,
required:true,
ref:'User'
    },

    Favbook:
    {

       
Name:{
    type:String,

},
Author:{
    type:String
},
Img:{
    type:String,
},
Category:{
    type:String,

},
Language:{
    type:String,
},
Description:{
    type:String,

},
        product:{
            type:mongoose.Schema.Types.ObjectId,
            ref:'Product',
        }
    }
,

},

{
    timestamps:true
}

)




const FavList=mongoose.model("FavList",FavListSchema);
export default FavList;