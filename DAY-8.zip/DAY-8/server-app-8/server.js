import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import cors from 'cors';
import colors from 'colors';
import ProductRoutes  from './Routes/ProductRoutes.js'
import userroutes from './Routes/UserRoutes.js'
import cartroutes from './Routes/cartroutes.js'
import Cart from "./models/Cartmodel.js"
import orderroutes from './Routes/OrderRoutes.js'
const app=express();
app.use(express.json());
app.use(cors());
dotenv.config();

app.use("/econ1/products",ProductRoutes);
app.use("/carts",cartroutes);
app.use("/users",userroutes);
app.use("/orders",orderroutes)
// app.use((err,req,res,next)=>{
//     const statusCode=res.statusCode === 200? 500 :res.statusCode
//     res.status(statusCode);
// res.json({
//     message:err.message,
// })   
// next();
// })

mongoose.connect("mongodb+srv://SAN3005:SAN3005@cluster0.9coqr.mongodb.net/ECON12?authSource=admin&replicaSet=atlas-mfdnmj-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true",{ 
    useNewUrlParser:true,
    useUnifiedTopology:true
})
.then(()=>console.log('im connected to atlas  database bro' .underline.blue))
.catch(err=>console.log(`${err}`.underline.red ));


// app.get("/",async(req,res)=>{
//     res.status(200).json("yoo im being summoned tell me your wish, i shall grant you any data you wish")
// })
app.get("/er",async(req,res)=>{
    const data=Cart.find();
    console.log(data)
})

app.listen(process.env.PORT ,console.log(`Hi im up and Running good and running on ${process.env.PORT}`.blue))