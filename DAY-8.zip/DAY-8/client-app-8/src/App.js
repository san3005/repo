import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import About from './About';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Footer from './components/Footer';
import ProductCard from './components/ProductCard';
import Cart from './Pages/Cart/Cart.js';
import SingleProduct from './components/ProductCard/SingleProduct';
import Signin from './Pages/Signin/Signin';
import Registration from './Pages/Registration/Registration';
import Profile from './Pages/Profile/Profile';
import Shipping from './Pages/Shipping/Shipping';
import Payment from './Pages/Shipping/Payment';
import PlaceOrder from './Pages/Shipping/PlaceOrder';

function App() {
  return (
    <>
    <div className='container1'style={{minHeight:"90vh"}} >
    <Router>
<Header/>
      <Routes>

        <Route path="/"  element={<ProductCard/>}/>
        <Route path="/signin" element={<Signin/>}/>
        <Route path="/cart" element={<Cart/>}>
          <Route path=":id/:qty" element={<Cart/>}/>
        </Route>
        <Route path="/shipping" element={<Shipping/>}/>
        <Route path="/payment" element={<Payment/>}/>
        <Route path="/placeorder" element={<PlaceOrder/>}/>

        <Route path="/products/:id" element={<SingleProduct/>}/>
<Route path="/register" element={<Registration/>}/>

      </Routes>
    </Router>

    </div>

        <Footer />
</>
  );
}

export default App;
