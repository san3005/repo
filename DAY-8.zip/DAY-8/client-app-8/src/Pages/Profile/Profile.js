// import React,{useEffect,useState} from 'react'
// import { useDispatch, useSelector } from 'react-redux';
// import { NavLink,Link,useLocation , useNavigate} from 'react-router-dom'
// import { userlogin } from '../../Actions/UserAction/UserActions';
// import { ToastContainer, toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import { Getdetails } from '../../Actions/UserAction/UserActions.js';

// const Profile = () => {
//   const location=  useLocation();
//     const dispatch=useDispatch();
//     const navigate=useNavigate()
//     const userdetailsdata=useSelector(state=>state.userdetails);
//     const{userdetails,error}=userdetailsdata;
//     console.log(userdetails);
//     const[name,setName]=useState("");
//     const[email,setEmail]=useState("");
//     const[password,setPassword]=useState("")
//     const[confirmpassword,setConfirmpassword]=useState("");
//     const[errormsg,setErrormsg]=useState(false);
//     const redirect=location.search?location.search.split("")[1]:"/cart";
//     useEffect(() => {
//         if(userdata.userdetails){
//           navigate("/cart")
      
//         }
      
       
//       }, [])
//     const handlesubmit=(e)=>{
//         e.preventDefault();
// if(password!==confirmpassword){
//     setErrormsg(true);
// }
// else{
//         dispatch(Registering(name,email,password));
//         navigate("/")

// }

// if(userdata.userdetails){
//     navigate("/cart")

//   }
// }
// // Navigate("/cart")


// const redirectinghandler=()=>{
//     // if(userdata.userdetails){
//     //     navigate("/cart")
    
//     //   }
//     }

//   return (
//       <>
//          {error ? (<div className="alert alert-danger" role="alert">
// {error}    </div>):("")}
//       {/* {error  ? (<p>{error}</p>) :("")} */}
//    {errormsg &&
// (
//     // toast.error("passwords don't match",{
//     //     theme:"dark"
//     // })
//     <div className='alert alert-danger'>
//         passwords not matching <span onClick={()=>setErrormsg(false)}>x</span>
//         </div>
// )}
// <div class="container4">


// 	<div class="screen" style={{height:"700px",width:"400px"}}>
     
// 		<div class="screen__content">
// 			<form class="login1" onSubmit={(e)=>handlesubmit(e)}>
// 				<div class="login__field">
// 					<i class="login__icon fas fa-user"></i>
// 					<input type="text" class="login__input"placeholder=" Name" value={name} onChange={(e)=>setName(e.target.value)} required/>
                    
//             	</div>
//                 <div class="login__field">
// 					<i class="login__icon bx bxl-gmail"></i>
// 					<input type="text" class="login__input"placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} required/>
                    
//             	</div>
// 				<div class="login__field">
// 					<i class="login__icon fas fa-lock"></i>
// 					<input type="password" class="login__input" placeholder="Password"  value={password} onChange={(e)=>setPassword(e.target.value)}  required/>
//                     {/* value={Password} */}
// 				</div>
//                 <div class="login__field">
// 					<i class="login__icon fas fa-lock"></i>
// 					<input type="password" class="login__input" placeholder="Confirm Password"  value={confirmpassword} onChange={(e)=>setConfirmpassword(e.target.value)} required/>
//                     {/* value={Password} */}
// 				</div>
// 				<button class="button login__submit" >
// 					<span class="button__text" onClick={redirectinghandler}>  Register Now</span>
// 					<i class="button__icon fas fa-chevron-right"></i>
// 				</button>		
		
// 			</form>
//            <h6> <NavLink to="/signin" style={{marginLeft:"30px",textDecoration:"none",color:"#000"}}>Already <span style={{color:'#fff'}}>have an account?</span></NavLink></h6>
           
// <ToastContainer />
// 		</div>
// 		<div class="screen__background">
// 			<span class="screen__background__shape screen__background__shape4"></span>
// 			<span class="screen__background__shape screen__background__shape3"></span>		
// 			<span class="screen__background__shape screen__background__shape2"></span>
// 			<span class="screen__background__shape screen__background__shape1"></span>
// 		</div>		
// 	</div>
// </div>  


// </>
// // {<>
// //     "NewCustomer" ? 
// //      <NavLink to={redirect?`/register?redirect=${redirect}`}>Register </NavLink>
    
// //      :"/"
// //      </> 
// //     } 
//   )
// }

// export default Profile


import React from 'react'

const Profile = () => {
  return (
    <div>Profile</div>
  )
}

export default Profile