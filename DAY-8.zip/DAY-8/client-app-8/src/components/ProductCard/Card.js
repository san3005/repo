import React,{useState,useEffect} from 'react'
import { NavLink } from 'react-router-dom'
import './Card.css'
import Rating from './Rating'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Card = ({product}) => {
  const[search,setSearch]=useState("")
  // const[checked,setChecked]=useState(false);
// console.log([...Array(product.Category),...product.Category]);
// const filtering=product.filter((i)=>i.Category===search)
// const filteredAll = product.filter(
//   item => item.Category === "Men")
console.log(search)

return (
    <div className='singleproduct '>
      {/* <input type="checkbox" value={checked} name={product.Category} checked={checked}    onChange={(e)=>setSearch(e.target.name)}
onClick={(e)=>setChecked(!checked)}/> */}
<div className="container3 mt-5 ">
<div className='card1 '>

    <img src={product.Img} className='card_img'/>
<div className="card_data">
  <div className="card_title">
{product.Name}  </div>
  <span className="card_price">{product.Price}</span>
 
 <Rating value={product.Rating} text={`${product.NumberofReviews} reviews`}/>
 <p>{product.Category}</p>
  <button className="btn btn card_button">
      <NavLink to={`/products/${product._id}`}  style={{color:"#f2a20c"}}>
          View </NavLink>


</button>
</div>
 </div>
 </div>

</div>
   
  )
}

export default Card