export const OrderDataReducer=(state={},action)=>{
switch(action.type){
    case'ORDER_SUCCESS':
    return{
        order:action.payload,
        success:true
    }
    case'ORDER_FAILED':
    return{
        error:action.payload
    }
    default:
        return state;
}
}