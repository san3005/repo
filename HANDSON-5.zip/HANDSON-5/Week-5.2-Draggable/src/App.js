import React from 'react';
import Draggable from 'react-draggable';
import "bootstrap/dist/css/bootstrap.css";
import Card from './Card';

function App(){
  return(
    <>
      <Card axis="x" title="Card1" subtitle=" im card1 and can be dragged across x axis" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident neque, placeat suscipit beatae eius ipsa a praesentium saepe reprehenderit minus, voluptatibus facilis asperiores 
      explicabo, velit rem laudantium dolores sint autem?"/>
      <Card title="Card2" axis="y" subtitle="  im card2 can be dragged across y axis" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident neque, placeat suscipit beatae eius ipsa a praesentium saepe reprehenderit minus, voluptatibus facilis asperiores explicabo, 
      velit rem laudantium dolores sint autem?"/>
      <Card title="Card3" subtitle="  im card3" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident neque, placeat suscipit beatae eius ipsa a praesentium saepe reprehenderit minus, voluptatibus facilis asperiores explicabo, velit rem laudan
      tium dolores sint autem?"/>
      <Card title="Card4" subtitle=" im card4" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident neque, placeat suscipit beatae eius ipsa a praesentium saepe reprehenderit minus, voluptatibus facili
      s asperiores explicabo, velit rem laudantium dolores sint autem?"/>
      <Draggable handle="strong">
          <div className="card" style={{display: 'flex',height:"200px",width:"18rem", flexDirection: 'column'}}>
            <strong className="cursor"><div>Drag here</div></strong>
            <div style={{overflow: 'scroll'}}>
              <div style={{background: 'crimson', whiteSpace: 'pre-wrap'}}>
                I have long scrollable content with a handle
                {'\n' + Array(40).fill('000').join('\n')}
              </div>
            </div>
          </div>
        </Draggable>
   </>
  )
}
export default App;
