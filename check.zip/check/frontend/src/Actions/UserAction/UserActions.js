import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export const userlogin=(email,password)=>async(dispatch)=>{
    try{

        const config={
headers:{
"Content-Type":"application/json"
}
        }
        const {data}= await axios.post("http://localhost:8001/users/loginuser",{"Email":email,"Password":password},config)
console.log(data);
        dispatch({
           type:'USER_LOGIN',
           payload:data

        })
        localStorage.setItem("userdetails",JSON.stringify(data));
toast.success("logged in")
    }
    catch(error){
    dispatch({type:'USER_LOGIN_FAIL',
        payload:error.response && 
        error.response.data.message ? error.response.data.message:error.message})
        toast.warning('Login failed')

    }
}
export const userlogout=()=>async(dispatch)=>{
    localStorage.removeItem("userdetails");

dispatch({
    type:'USER_LOGOUT'
})


}

